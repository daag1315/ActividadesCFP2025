    function calcularMasaCorporal(peso,altura){
        imc=peso/(altura**2)
        return imc;
    }
    
    function obtenerEstado(imc){

        //Por si acaso coloqué las opciones para los resultados que están debajo del Normal
        if(imc>=18.5 && imc<=24.9){
            return "Su IMC es normal, está bien de salud"
        }
        else if(imc<=15){
            return "Su IMC es muy bajo, tiene delgadez muy severa"
        }
        else if(imc>=15 && imc<=15.9){
            return "Su IMC es bajo, tiene delgadez severa"
        }
        else if(imc>=16 && imc<=18.4){
            return "Su IMC es bajo, tiene delgadez"
        }
        else if(imc>=25 && imc<=29.99){
            return "Su IMC es alto, tiene sobrepeso"
        }
        else if(imc>=30 && imc<=34.9){
            return "Su IMC es alto, tiene obesidad moderada"
        }
        else if(imc>=35 && imc<=39.99){
            return "Su IMC es alto, tiene obesidad severa"
        }
        else if(imc>=40){
            return "Su IMC es alto, tiene obesidad mórbida"
        }
    }

    function calculo(){
        peso=parseFloat(document.getElementById("peso").value)
        altura=parseFloat(document.getElementById("altura").value)
        
        imc=calcularMasaCorporal(peso,altura)

        texto="El IMC es de "+imc+". "+obtenerEstado(imc)
        document.getElementById("mensaje").value=texto
    }
    
