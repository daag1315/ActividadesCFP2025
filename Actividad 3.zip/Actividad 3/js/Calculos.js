function calcularMasaCorporal(){
    imc=document.getElementById("imc")
    peso=parseFloat(document.getElementById("peso").value)
    altura=parseFloat(document.getElementById("altura").value)
    imc.value=peso/(altura**2)
}

function obtenerEstado(){
    estado=document.getElementById("estado")
    peso=parseFloat(document.getElementById("peso").value)
    altura=parseFloat(document.getElementById("altura").value)
    imc=peso/(altura**2)

    //Por si acaso coloqué las opciones para los resultados que están debajo del Normal
    if(imc>=18.5 && imc<=24.9){
        estado.value="Su IMC es normal, está bien de salud"
    }
    else if(imc<=15){
        estado.value="Su IMC es muy bajo, tiene delgadez muy severa"
    }
    else if(imc>=15 && imc<=15.9){
        estado.value="Su IMC es bajo, tiene delgadez severa"
    }
    else if(imc>=16 && imc<=18.4){
        estado.value="Su IMC es bajo, tiene delgadez"
    }
    else if(imc>=25 && imc<=29.99){
        estado.value="Su IMC es alto, tiene sobrepeso"
    }
    else if(imc>=30 && imc<=34.9){
        estado.value="Su IMC es alto, tiene obesidad moderada"
    }
    else if(imc>=35 && imc<=39.99){
        estado.value="Su IMC es alto, tiene obesidad severa"
    }
    else if(imc>=40){
        estado.value="Su IMC es alto, tiene obesidad mórbida"
    }
}